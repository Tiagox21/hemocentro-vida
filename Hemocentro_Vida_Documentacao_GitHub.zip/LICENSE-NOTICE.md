# Licenciamento e atribuições

Este pacote não define uma licença de código aberto. Antes de adicionar uma licença, a equipe deve decidir em conjunto os termos de distribuição do projeto e verificar as licenças das bibliotecas e recursos externos usados pela interface.

A publicação pública do repositório não autoriza automaticamente reutilização irrestrita do código.
