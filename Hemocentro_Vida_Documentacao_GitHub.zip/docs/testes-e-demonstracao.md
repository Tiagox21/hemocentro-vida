# Testes e demonstração

## Roteiro proposto — cinco minutos
| Tempo | Ação |
|---|---|
| 00:00–00:40 | Abrir cadastro e mostrar um doador fictício |
| 00:40–01:30 | Executar triagem e mostrar resultado permitido/bloqueado |
| 01:30–02:30 | Registrar coleta de candidato apto; mostrar unidade fixa/móvel |
| 02:30–03:30 | Fracionar bolsa e exibir componentes |
| 03:30–04:30 | Consultar estoque, validade e requisição |
| 04:30–05:00 | Apresentar painel de testes e limitações |

**Este é um roteiro sugerido, não um registro de execução.** Deve ser ensaiado no navegador, com dados fictícios, antes da avaliação.

## Testes identificados
A versão atual apresenta uma seção intitulada **“Sprint 5: 10 Testes”**. A existência dessa seção no código não demonstra que os dez testes passaram em execução independente, nem que pertencem às Sprints 1 e 2.

## Checklist pré-apresentação
- [ ] Abrir `index.html` e conferir o carregamento de recursos.
- [ ] Usar exclusivamente doadores fictícios.
- [ ] Confirmar os caminhos e estados iniciais.
- [ ] Validar cada transição antes da apresentação.
- [ ] Executar o roteiro cronometrado.
- [ ] Registrar capturas de tela e resultados reais dos testes.

## Capturas de referência
![Triagem](evidencias/triagem.png)
![Doadores](evidencias/doadores.png)
![Estoque](evidencias/estoque.png)

As imagens foram extraídas de material da apresentação fornecido; são **recortes ilustrativos da versão disponibilizada**, não prova datada de execução em 21/10.
