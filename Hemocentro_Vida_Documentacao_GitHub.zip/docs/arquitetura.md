# Arquitetura técnica

## Visão geral
A versão fornecida é uma aplicação de página única em `index.html`, composta por HTML, CSS e JavaScript. A navegação ocorre entre seções do documento e a lógica é executada no navegador.

```text
Navegador
  ├── Interface HTML/CSS
  ├── Lógica JavaScript
  └── localStorage (dados locais do navegador)
```

## Execução
Abra `index.html` no navegador. Algumas bibliotecas e recursos visuais são carregados por **CDN**, portanto podem exigir conexão com a internet.

## Persistência
O código utiliza `localStorage`: os dados ficam no navegador utilizado e não são compartilhados entre computadores. Limpar os dados do navegador pode eliminar os registros locais.

## Limites arquiteturais
- Não foi identificado backend operacional nem banco de dados remoto no arquivo entregue.
- Não há garantia de autenticação, controle de acesso, backups ou trilha de auditoria clínica.
- Não há validação independente da segurança ou das regras clínicas.
- Não usar dados pessoais reais durante testes acadêmicos.

## Evolução recomendada
Separar camadas, criar API e persistência controlada, estabelecer testes automatizados independentes e implantar controles de privacidade e segurança antes de qualquer cenário real.
