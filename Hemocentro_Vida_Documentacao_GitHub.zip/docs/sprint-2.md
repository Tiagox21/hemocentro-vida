# Sprint 2 — Escopo, primeira página e documentação

**Período planejado:** 08/10 a 21/10/2026. **Capacidade estimada:** 10 horas de trabalho da squad.

## Objetivo do planejamento
Definir público-alvo e escopo inicial, iniciar uma página HTML/CSS e organizar documentação e atividades.

| Compromisso | Responsáveis | Critério previsto |
|---|---|---|
| Definir público e escopo | Toda a equipe | Escopo documentado e aprovado |
| Criar a primeira página | Tiago, Diego, Miguel e Guilherme | Página executável e organizada |
| Organizar a documentação | Beatriz, Rickelme e Kauê | Documentação disponível |
| Atualizar e acompanhar o Trello | Toda a equipe | Quadro atualizado conforme progresso |

## Resultado informado pela equipe
Um integrante confirmou que **os quatro compromissos foram concluídos** e que o **protótipo já estava funcional até 21/10/2026**, incluindo cadastro, triagem, coleta, fracionamento, estoque e requisições.

**Precisão documental:** o arquivo de origem é um **planejamento**, não uma ata de aceite. O código atual comprova a implementação dos módulos na versão entregue, mas não permite verificar a data exata de cada um. O quadro Trello, segundo a equipe, não era atualizado regularmente; portanto, suas datas não são tomadas como medição exclusiva de entrega.

## Planejado versus demonstrável
A primeira página executável é sustentada pelo arquivo [`index.html`](../index.html). O sistema atual vai além de uma página estática. A confirmação do prazo e do encerramento dos compromissos foi fornecida pela equipe.

## Escopo inicialmente adiado
O planejamento original mencionou como itens futuros o sistema completo, integração com banco de dados, cadastro funcional, agendamento e funções administrativas. **O cadastro funcional aparece na versão atual do HTML**; a documentação não afirma que todas as funções futuras foram concluídas na Sprint 2.

## Fontes
- [Planejamento original](fontes/planejamento-sprint-2-original.docx)
- [Código atual](../index.html)
