# Documentação — Hemocentro Vida

Documentação de apoio à avaliação acadêmica das **Sprints 1 e 2**.

| Arquivo | Conteúdo |
|---|---|
| [Sprint 1](sprint-1.md) | Objetivos, decisões, dificuldades e conciliação do resultado |
| [Sprint 2](sprint-2.md) | Quatro compromissos, responsáveis, evidências e resultado informado |
| [Requisitos e escopo](requisitos-e-escopo.md) | Público, necessidades e funções da aplicação |
| [Arquitetura](arquitetura.md) | Tecnologias, execução e persistência |
| [Regras de negócio](regras-de-negocio.md) | Regras identificadas e cuidados de uso |
| [Testes e demonstração](testes-e-demonstracao.md) | Plano de validação e roteiro de cinco minutos |
| [Evidências e rastreabilidade](evidencias-e-rastreabilidade.md) | O que cada fonte comprova e o que não comprova |
| [Limitações e próximos passos](limitacoes-e-proximos-passos.md) | Riscos técnicos e evolução recomendada |
| [Fontes originais](fontes/) | Relatório da Sprint 1 e planejamento da Sprint 2 |
| [Capturas](evidencias/) | Recortes da versão disponibilizada do sistema |

**Critério de transparência:** os documentos originais registram a situação na data em que foram escritos. A conclusão posterior das sprints e a disponibilidade do protótipo até 21/10 foram **informadas pela equipe**, não inferidas de datas de commits ou movimentações do Trello.

O código atual inclui funcionalidades e referências a sprints posteriores; não atribuímos automaticamente todos esses recursos à Sprint 2.
