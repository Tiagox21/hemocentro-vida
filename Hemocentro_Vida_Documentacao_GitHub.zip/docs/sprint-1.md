# Sprint 1 — Organização e definição inicial

**Período:** 17/09 a 30/09/2026, conforme a apresentação da equipe.

## Objetivo documentado
Definir a identidade visual, a metodologia de trabalho e a distribuição de responsabilidades; discutir o público-alvo e o alcance do sistema.

## Decisões registradas
- **Método:** Scrum; **quadro:** Trello.
- **Fluxo do quadro:** Product Backlog → Sprint Backlog → A Fazer → Em andamento → Concluído.
- **Tecnologias escolhidas:** HTML, CSS e JavaScript.
- **Identidade visual:** branco predominante, vermelho de destaque e preto para textos/detalhes.
- **Responsabilidades:** programação (Tiago, Diego, Miguel e Guilherme); documentação (Beatriz, Rickelme e Kauê); design (todos).

## Situação do relatório original
O relatório descreveu **4 cartões comprometidos e 0 concluídos naquele momento**, classificou o objetivo como parcialmente atingido e apontou indefinição sobre atendimento a uma unidade ou a várias unidades.

## Atualização informada pela equipe
Posteriormente, um integrante confirmou **conclusão dos quatro compromissos da Sprint 1**. A conclusão final não está registrada no relatório inicial. Para evitar contradições, o resultado final é identificado como **confirmação da equipe**, enquanto o número 0/4 é preservado como retrato documental anterior.

## Evidências
- [Relatório original](fontes/relatorio-sprint-1-original.pdf).
- [Código da versão disponibilizada](../index.html), que evidencia a materialização posterior do projeto, sem datar cada implementação.

## Aprendizado
Registrar o aceite e a data de conclusão de cada compromisso no momento do encerramento, sem depender exclusivamente do status posterior do quadro.
