# Requisitos e escopo

## Problema abordado
Apoiar, em ambiente demonstrativo, a organização do cadastro de doadores e das etapas de triagem, coleta, processamento, estoque e atendimento de requisições.

## Público e abrangência
O relatório inicial registra uma dúvida sobre atender **uma unidade** ou **várias unidades**. A equipe informou que o compromisso de definição do escopo foi concluído, mas **não foi fornecida a decisão formal final em documento específico**. Não presumimos qual opção foi aprovada.

## Funcionalidades verificáveis na versão atual
| Área | Comportamento identificado no HTML |
|---|---|
| Doadores | Cadastro e listagem |
| Triagem | Formulário e validações demonstrativas |
| Coleta | Registro de coleta e bolsa |
| Fracionamento | Geração de hemocomponentes |
| Requisições | Registro e validações demonstrativas |
| Estoque | Consulta de itens, vencimentos e situação |
| Testes | Tela de execução de casos de teste |

## Requisitos não demonstrados como concluídos
Autenticação robusta, backend e banco remoto, integração com sistemas clínicos, interoperabilidade, auditoria institucional, agendamento completo e adequação regulatória para uso real.

## Critério de uso
O protótipo é **acadêmico**. Não utilizar decisões automatizadas como parecer médico ou validação transfusional real.
