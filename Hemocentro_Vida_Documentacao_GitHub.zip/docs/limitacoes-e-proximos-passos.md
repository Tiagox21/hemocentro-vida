# Limitações e próximos passos

## Dificuldades identificadas
1. Definição inicial do público-alvo e abrangência.
2. Atualização irregular do Trello, conforme informado pela equipe.
3. Ausência de registro final individualizado dos compromissos nos documentos fornecidos.
4. Dificuldade de associar funcionalidades do HTML atual a versões e datas históricas.

## Limitações do produto atual
Persistência local no navegador; ausência de backend e autenticação; uso acadêmico de regras clínicas; necessidade de validar segurança, privacidade, integridade e comportamento dos fluxos.

## Próximas ações sugeridas
- Publicar versão identificada e README.
- Criar critérios de aceite e anexar evidências por sprint.
- Documentar a decisão formal sobre unidade única ou múltiplas unidades.
- Registrar testes reproduzíveis e seus resultados.
- Avaliar banco de dados, autenticação, backups e LGPD antes de qualquer implantação real.
- Manter o quadro atualizado e vincular cartões a versões do código.

Essas ações são **recomendações de evolução**, não promessas já concluídas nas Sprints 1 e 2.
