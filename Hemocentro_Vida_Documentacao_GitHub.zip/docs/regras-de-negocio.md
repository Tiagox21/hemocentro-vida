# Regras de negócio — versão demonstrativa

O HTML identifica regras como **RN-04** (somente candidatos aprovados podem seguir para coleta), **RN-05** (validade de hemocomponentes contada segundo evento de referência no fluxo) e **RN-08** (fracionamento uma única vez por bolsa e sem reversão).

Também há validações demonstrativas de elegibilidade e compatibilidade no fluxo de triagem e requisição.

## Cuidados de interpretação
- As regras aqui descritas são **comportamentos do protótipo**, não um parecer sobre sua conformidade clínica ou legal.
- Critérios de doação, intervalos, compatibilidade, conservação e validade exigem validação por profissionais e normas vigentes antes de qualquer uso real.
- A identificação RN-04/RN-05/RN-08 reproduz os rótulos do código; não constitui uma especificação integral de todas as regras do sistema.

## Verificação
Consultar os formulários e funções JavaScript em [`index.html`](../index.html). Executar cenários apenas com dados fictícios.
