# Evidências e rastreabilidade

| Afirmação | Fonte | Grau de comprovação |
|---|---|---|
| Sprint 1 definiu Scrum, Trello, responsabilidades e cores | Relatório S1 | Documental |
| Relatório inicial S1 registrava 0/4 cartões concluídos | Relatório S1 | Documental naquele momento |
| Quatro compromissos da Sprint 1 foram concluídos | Confirmação posterior da equipe | Declaração da equipe; sem ata final anexada |
| Sprint 2 planejou quatro compromissos e 10 horas | Planejamento S2 | Documental |
| Quatro compromissos da Sprint 2 foram concluídos | Confirmação posterior da equipe | Declaração da equipe; sem ata final anexada |
| Protótipo tinha módulos funcionais até 21/10 | Confirmação posterior da equipe | Prazo informado; sem histórico de versões datado |
| Módulos estão implementados na versão entregue | Código HTML | Evidência de implementação atual |
| Trello não era atualizado regularmente | Esclarecimento da equipe | Declaração da equipe |

## Nota sobre o Trello
O Trello não deve ser usado como única medida do desenvolvimento: a equipe informou que o quadro teve atualização irregular e que isso foi esclarecido ao professor. Isso **não elimina a necessidade de transparência** sobre o relatório original e as evidências disponíveis.

## Capturas e documentação
As imagens em `evidencias/` são recortes da versão apresentada. Os documentos originais permanecem preservados em `fontes/`.

## Datas
Não foram inventadas datas de commits, aceites, testes ou encerramentos. A data de publicação do GitHub será posterior à produção inicial do sistema.
