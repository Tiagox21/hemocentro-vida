# Hemocentro Vida

Projeto acadêmico de **Análise e Projeto de Sistemas II (APS II)**: interface de apoio ao fluxo de doação de sangue e à gestão de hemocomponentes.

> **Finalidade acadêmica:** sistema demonstrativo. Não é software clínico homologado nem deve ser usado para decidir elegibilidade de doadores, compatibilidade transfusional ou liberação real de hemocomponentes.

## Executar
1. Baixe este repositório ou clone-o.
2. Abra `index.html` em um navegador atualizado, com acesso à internet para carregar as bibliotecas referenciadas por CDN.
3. Navegue pelas seções e utilize **dados fictícios** nos testes.

O projeto é apresentado em um único arquivo HTML com CSS e JavaScript incorporados. Os dados são guardados no `localStorage` do navegador: não há banco de dados remoto, autenticação de usuários nem sincronização entre dispositivos.

## Funcionalidades identificadas no código
- Cadastro e consulta de doadores.
- Triagem e validação demonstrativa de aptidão.
- Registro de coleta e rastreabilidade de bolsas.
- Fracionamento em hemocomponentes.
- Requisições e validações demonstrativas de compatibilidade.
- Estoque e acompanhamento de validade.
- Painel de testes automatizados rotulado no código como **Sprint 5**.

As funcionalidades acima descrevem a **versão do arquivo atualmente disponibilizada**, não comprovam isoladamente quando cada módulo foi criado.

## Sprints 1 e 2
A equipe informou que concluiu os quatro compromissos de cada sprint e que o protótipo já estava funcional até **21/10/2026**. O relatório original da Sprint 1 registrava **0/4 cartões concluídos no momento de sua redação**; o Trello foi atualizado de forma irregular, segundo esclarecimento da equipe. Por isso, a documentação separa o **registro contemporâneo** da **confirmação posterior da equipe**.

- [Visão geral da documentação](docs/README.md)
- [Sprint 1](docs/sprint-1.md)
- [Sprint 2](docs/sprint-2.md)
- [Requisitos e escopo](docs/requisitos-e-escopo.md)
- [Arquitetura](docs/arquitetura.md)
- [Regras de negócio](docs/regras-de-negocio.md)
- [Testes e demonstração](docs/testes-e-demonstracao.md)
- [Evidências e rastreabilidade](docs/evidencias-e-rastreabilidade.md)
- [Limitações e próximos passos](docs/limitacoes-e-proximos-passos.md)

## Equipe
Tiago Araujo (42345189), Diego Lugano (43973299), Rickelme Santos (45643580), Beatriz Santos (43368859), Miguel Soares (41847851), Guilherme Bernardo (44870167) e Kauê Dias (41837681).

## Referências
- [Quadro da equipe no Trello](https://trello.com/b/Ojc84enu)
- Documentos originais em [`docs/fontes/`](docs/fontes/).

## Histórico e publicação
Este repositório disponibiliza o código e a documentação para avaliação. **A data do commit no GitHub não representa a data original de desenvolvimento.** Não inserir informações reais de pacientes ou doadores.
